WASEEM COMPUTER WEBSITE — QUICK SETUP

Files included:
- index.html: responsive website
- logo.png: generated Waseem Computer logo

WhatsApp is already set to 0332-9383949. The website link uses Pakistan country code 92.

IMPORTANT BEFORE PUBLISHING:
1. Replace the example products in the products array in index.html with your actual product names, specifications and prices.
2. Product listings are placeholders and do not represent confirmed stock or prices.
3. You can change the location and contact details in index.html if needed.

FREE PUBLISHING WITH GITHUB PAGES:
- Sign in/create a GitHub account.
- Create a public repository named waseem-computer-store.
- Upload index.html and logo.png to the repository root.
- Open Settings > Pages.
- Choose Deploy from a branch, select main and /(root), then Save.
- GitHub will provide a public website address after deployment.

This is a website package, not yet a live hosted website. A custom domain usually costs extra.
